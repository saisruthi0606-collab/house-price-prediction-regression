import pandas as pd
import numpy as np

data={
     'size_sqft':np.random.randint(300,3000,100),
     'bedrooms': np.random.randint(2,6,100),
     'age_years':np.random.randint(1,20,100)
}
df=pd.DataFrame(data)
df['price']=(
    50000+
    df['size_sqft'] * 150+
    df['bedrooms'] * 20000+
    (40 - df['age_years']) * 1500+
    np.random.normal(0,10000,100)
).astype(int)  
df.to_csv('house_prices.csv',index=False)
print("dataset created and saved to house_prices.csv")
































