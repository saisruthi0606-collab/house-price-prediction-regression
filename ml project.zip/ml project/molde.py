import pandas as pd
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score
import joblib
df=pd.read_csv('house_prices.csv')
print("Dataset loaded successfully.")
print("\nChecking for missing values:")
print(df.isnull().sum())
x=df[['size_sqft','bedrooms','age_years']]
y=df['price']
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=42)
print("\nData split into training and testing sets.")
print(f"Training set size:{x_train.shape[0]} samples")
print(f"Testing set size:{x_train.shape[0]} samples")
model=RandomForestRegressor(n_estimators=100,random_state=42)
print("\nTraining the Random Forest Regressor model...")
model.fit(x_train,y_train)
print("Model training complete.")
y_pred=model.predict(x_test)
r2=r2_score(y_test,y_pred)
print(f"\nModel R-squared(Accuracy) score:{r2:.2%}")
joblib.dump(model,'house_price_model.joblib')
print("\nModel saves as 'house_price_model.joblib'")