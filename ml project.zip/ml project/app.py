from flask import Flask, render_template, request
import joblib

# Step 1: Create a Flask application instance
app = Flask(__name__)

# Step 2: Load the trained model
# Make sure your 'house_price_model.joblib' file is in the same directory.
model = joblib.load('house_price_model.joblib')
print("Model loaded successfully for Flask app.")

# Step 3: Define the main route for the home page
@app.route('/')
def home():
    # It shows the 'index.html' page.
    return render_template('index.html')

# Step 4: Define the prediction route
@app.route('/predict', methods=['POST'])
def predict():
    # Get the data submitted by the user from the form.
    size_sqft = int(request.form['size_sqft'])
    bedrooms = int(request.form['bedrooms'])
    age_years = int(request.form['age_years'])

    # Put the input values into a format the model understands.
    features = [[size_sqft, bedrooms, age_years]]

    # Use the loaded model to make a prediction.
    prediction = model.predict(features)[0]

    # Format the prediction to be a clean, readable number.
    predicted_price = f"{prediction:,.2f}"

    # Render the template again, passing the prediction to it.
    return render_template('index.html', prediction=predicted_price)

# Step 5: Run the app
if __name__ == '__main__':
    app.run(debug=True)
